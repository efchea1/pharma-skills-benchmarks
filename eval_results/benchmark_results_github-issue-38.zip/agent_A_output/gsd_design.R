library(gsDesign)
library(gsDesign2)
library(jsonlite)

# Helpers from examples.md
calc_expected_events <- function(T_cal, lambdaC, hr, eta, gamma_vec, R_vec, ratio_val) {
  lambdaE <- lambdaC * hr
  enroll_starts <- c(0, cumsum(R_vec[-length(R_vec)]))
  enroll_ends <- cumsum(R_vec)
  
  total_events <- 0
  n_pts <- 100
  for (i in seq_along(gamma_vec)) {
    s_start <- enroll_starts[i]
    s_end <- min(enroll_ends[i], T_cal)
    if (s_start >= T_cal) next
    rate <- gamma_vec[i]
    dt <- (s_end - s_start) / n_pts
    for (k in 1:n_pts) {
      et <- s_start + (k - 0.5) * dt
      fup <- T_cal - et
      # Arm 1 (Control)
      prob_c <- (lambdaC / (lambdaC + eta)) * (1 - exp(-(lambdaC + eta) * fup))
      # Arm 2 (Experimental)
      prob_e <- (lambdaE / (lambdaE + eta)) * (1 - exp(-(lambdaE + eta) * fup))
      total_events <- total_events + 
        rate * (1 / (1 + ratio_val)) * prob_c * dt +
        rate * (ratio_val / (1 + ratio_val)) * prob_e * dt
    }
  }
  total_events
}

find_event_time <- function(target_events, lambdaC, hr, eta, gamma_vec, R_vec, ratio_val) {
  lo <- 0.1; hi <- sum(R_vec) + 200
  for (i in 1:100) {
    mid <- (lo + hi) / 2
    d <- calc_expected_events(mid, lambdaC, hr, eta, gamma_vec, R_vec, ratio_val)
    if (d < target_events) lo <- mid else hi <- mid
    if (abs(hi - lo) < 0.001) break
  }
  mid
}

# --- Inputs ---
ctrl_median <- 14
hr_target <- 0.72
alpha_2sided <- 0.05
alpha_1sided <- alpha_2sided / 2
power_target <- 0.90
ratio <- 1
eta <- -log(1 - 0.01)

gamma <- c(60, 15, 5)
R <- c(6, 12, 6)
total_N <- sum(gamma * R)

# --- Step 1: Compute required events ---
delta <- log(1/hr_target)/2
cat(sprintf("Delta: %f\n", delta))

initial_gsd <- gsDesign(k=2, test.type=1, alpha=alpha_1sided, beta=1-power_target, 
                        timing=0.4, sfu=sfLDOF, delta=delta)
cat(sprintf("n.I from gsDesign: IA=%.2f, FA=%.2f\n", initial_gsd$n.I[1], initial_gsd$n.I[2]))

required_events_fa <- ceiling(initial_gsd$n.I[2])
required_events_ia <- ceiling(initial_gsd$n.I[1])

cat(sprintf("Required Events: IA=%d, FA=%d\n", required_events_ia, required_events_fa))

# --- Step 2: Timing ---
lambdaC <- log(2) / ctrl_median

ia_time <- find_event_time(required_events_ia, lambdaC, hr_target, eta, gamma, R, ratio)
fa_time <- find_event_time(required_events_fa, lambdaC, hr_target, eta, gamma, R, ratio)

cat(sprintf("Event-driven times: IA=%.2f, FA=%.2f\n", ia_time, fa_time))

# Minimum follow-up constraint: 12 months for last patient
# Last patient enrolled at month 24
min_fa_time <- 24 + 12
if (fa_time < min_fa_time) {
    cat(sprintf("FA time %.2f is before min follow-up %.2f. Pushing FA to %.2f.\n", fa_time, min_fa_time, min_fa_time))
    fa_time <- min_fa_time
}

# Re-calculate events at actual FA time
actual_events_fa <- ceiling(calc_expected_events(fa_time, lambdaC, hr_target, eta, gamma, R, ratio))
actual_events_ia <- required_events_ia 
actual_ia_time <- ia_time

cat(sprintf("Actual Analysis Times: IA=%.2f, FA=%.2f\n", actual_ia_time, fa_time))
cat(sprintf("Actual Events: IA=%d, FA=%d\n", actual_events_ia, actual_events_fa))

# --- Step 3: Design with actual events ---
if_ia <- actual_events_ia / actual_events_fa

final_gsd <- gsDesign(k=2, test.type=4, alpha=alpha_1sided, timing=if_ia, 
                      n.I=c(actual_events_ia, actual_events_fa),
                      sfu=sfLDOF, sfl=sfHSD, sflpar=-20)

# Re-calculate power at target HR
final_gsd_h1 <- gsDesign(k=2, test.type=4, alpha=alpha_1sided, timing=if_ia, 
                         n.I=c(actual_events_ia, actual_events_fa),
                         sfu=sfLDOF, sfl=sfHSD, sflpar=-20,
                         delta=delta, delta1=delta, delta0=0)
power_final <- sum(final_gsd_h1$upper$prob[,2])

cat(sprintf("Final Power: %.2f%%\n", power_final * 100))

# Save results
results <- list(
  N = total_N,
  events = c(actual_events_ia, actual_events_fa),
  times = c(actual_ia_time, fa_time),
  power = power_final,
  hr_target = hr_target,
  alpha_1sided = alpha_1sided,
  ia_if = if_ia,
  bounds_z = final_gsd$upper$bound,
  bounds_p = pnorm(-final_gsd$upper$bound),
  bounds_hr = exp(-final_gsd$upper$bound * 2 / sqrt(c(actual_events_ia, actual_events_fa)))
)
write_json(results, "/tmp/benchmark_github-issue-38/agent_A/output_A/gsd_results.json", auto_unbox=TRUE, pretty=TRUE)

# Boundary summary
summary_tab <- gsBoundSummary(final_gsd)
write.csv(summary_tab, "/tmp/benchmark_github-issue-38/agent_A/output_A/gsd_boundary_summary.csv", row.names=FALSE)
