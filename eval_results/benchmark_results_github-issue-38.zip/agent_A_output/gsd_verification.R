library(lrstat)
library(jsonlite)

# Load design results
res <- fromJSON("/tmp/benchmark_github-issue-38/agent_A/output_A/gsd_results.json")

# Parameters
k <- 2
alpha_1sided <- res$alpha_1sided
hr_target <- res$hr_target
ctrl_median <- 14
lambda2 <- log(2) / ctrl_median
lambda1 <- lambda2 * hr_target
eta <- -log(1 - 0.01)

gamma <- c(60, 15, 5)
R <- c(6, 12, 6)
accrualTime <- c(0, 6, 18)
total_n <- res$N

# Verification under H1
cat("Running simulation under H1...\n")
sim_h1 <- lrsim(
  kMax = k,
  criticalValues = res$bounds_z,
  futilityBounds = rep(-6, k - 1),
  allocation1 = 1, allocation2 = 1,
  accrualTime = accrualTime,
  accrualIntensity = gamma,
  n = total_n,
  piecewiseSurvivalTime = 0,
  lambda1 = lambda1,
  lambda2 = lambda2,
  gamma1 = eta, gamma2 = eta,
  plannedEvents = res$events,
  maxNumberOfIterations = 10000,
  seed = 12345
)

# Verification under H0
cat("Running simulation under H0...\n")
sim_h0 <- lrsim(
  kMax = k,
  criticalValues = res$bounds_z,
  futilityBounds = rep(-6, k - 1),
  allocation1 = 1, allocation2 = 1,
  accrualTime = accrualTime,
  accrualIntensity = gamma,
  n = total_n,
  piecewiseSurvivalTime = 0,
  lambda1 = lambda2, # HR=1
  lambda2 = lambda2,
  gamma1 = eta, gamma2 = eta,
  plannedEvents = res$events,
  maxNumberOfIterations = 10000,
  seed = 67890
)

# Results
cat("\n--- Verification Results ---\n")
power_sim <- sim_h1$overview$overallReject * 100
alpha_sim <- sim_h0$overview$overallReject * 100
events_sim <- sim_h1$overview$numberOfEvents
times_sim <- sim_h1$overview$analysisTime

cat(sprintf("Power (H1): Calc=%.2f%%, Sim=%.2f%%\n", res$power * 100, power_sim))
cat(sprintf("Type I Error (H0): Calc=%.2f%%, Sim=%.2f%%\n", alpha_1sided * 100, alpha_sim))
cat(sprintf("Events IA: Calc=%d, Sim=%.1f\n", res$events[1], events_sim[1]))
cat(sprintf("Events FA: Calc=%d, Sim=%.1f\n", res$events[2], events_sim[2]))
cat(sprintf("Timing IA: Calc=%.2f, Sim=%.2f\n", res$times[1], times_sim[1]))
cat(sprintf("Timing FA: Calc=%.2f, Sim=%.2f\n", res$times[2], times_sim[2]))

# Create log
log_lines <- c(
  "# GSD Verification Log",
  "**Design**: OS in 2L RCC",
  sprintf("**Date**: %s", Sys.Date()),
  "**Simulations**: 10,000 reps",
  "",
  "| Metric | Calculated | Simulated | Criterion | Pass? |",
  "|--------|-----------|-----------|-----------|-------|",
  sprintf("| Power (H1) | %.2f%% | %.2f%% | ±2 pp | %s |", res$power*100, power_sim, ifelse(abs(res$power*100 - power_sim) <= 2, "YES", "NO")),
  sprintf("| Type I error (H0) | %.2f%% | %.2f%% | ±0.5 pp | %s |", alpha_1sided*100, alpha_sim, ifelse(abs(alpha_1sided*100 - alpha_sim) <= 0.5, "YES", "NO")),
  sprintf("| Events IA | %d | %.1f | ±5%% | %s |", res$events[1], events_sim[1], ifelse(abs(res$events[1] - events_sim[1]) <= res$events[1]*0.05, "YES", "NO")),
  sprintf("| Events FA | %d | %.1f | ±5%% | %s |", res$events[2], events_sim[2], ifelse(abs(res$events[2] - events_sim[2]) <= res$events[2]*0.05, "YES", "NO")),
  sprintf("| Timing IA (mo) | %.2f | %.2f | ±1 mo | %s |", res$times[1], times_sim[1], ifelse(abs(res$times[1] - times_sim[1]) <= 1, "YES", "NO")),
  sprintf("| Timing FA (mo) | %.2f | %.2f | ±1 mo | %s |", res$times[2], times_sim[2], ifelse(abs(res$times[2] - times_sim[2]) <= 1, "YES", "NO")),
  "",
  sprintf("## Overall: %s", ifelse(abs(res$power*100 - power_sim) <= 2 && abs(alpha_1sided*100 - alpha_sim) <= 0.5, "PASS", "FAIL"))
)
writeLines(log_lines, "/tmp/benchmark_github-issue-38/agent_A/output_A/gsd_verification_log.md")
