# GSD Verification Log
**Design**: OS in 2L RCC
**Date**: 2026-04-21
**Simulations**: 10,000 reps

| Metric | Calculated | Simulated | Criterion | Pass? |
|--------|-----------|-----------|-----------|-------|
| Power (H1) | 90.08% | 90.25% | ±2 pp | YES |
| Type I error (H0) | 2.50% | 2.63% | ±0.5 pp | YES |
| Events IA | 156 | 156.0 | ±5% | YES |
| Events FA | 391 | 391.0 | ±5% | YES |
| Timing IA (mo) | 14.91 | 14.90 | ±1 mo | YES |
| Timing FA (mo) | 44.17 | 44.70 | ±1 mo | YES |

## Overall: PASS
