library(gsDesign)

# Parameters
alpha <- 0.05
power <- 0.90
hr <- 0.72
ratio <- 1
k <- 2
timing <- 0.4 # 40% interim
control_median <- 14
dropout_rate_monthly <- 0.01

# Conversion
lambda_c <- log(2) / control_median
lambda_e <- lambda_c * hr
eta <- -log(1 - dropout_rate_monthly)

# Enrollment plan (proportions)
enroll_rates <- c(60, 15, 5)
enroll_durations <- c(6, 12, 6)

# Design using gsSurv
fit <- gsSurv(k = k,
              test.type = 4, 
              alpha = alpha/2, 
              beta = 1 - power, 
              timing = timing, 
              sfu = sfLDOF,
              sfl = sfHSD,
              sflpar = -4,
              lambdaC = lambda_c,
              hr = hr,
              eta = eta,
              gamma = enroll_rates, 
              R = enroll_durations,
              T = 36, 
              minfup = 12)

# Save results
sink("/tmp/benchmark_github-issue-38/agent_B/output_B/results.txt")
cat("Trial Design Report: Phase 3 Renal Cell Carcinoma\n")
cat("================================================\n\n")
cat("Primary Endpoint: Overall Survival (OS)\n")
cat("Control Median OS: 14 months\n")
cat("Hazard Ratio (Target): 0.72\n")
cat("Randomization Ratio: 1:1\n")
cat("Power: 90%\n")
cat("Alpha (2-sided): 0.05\n")
cat("Group Sequential Design: O'Brien-Fleming efficacy spending\n")
cat("Interim Analysis: 40% of events (non-binding futility)\n\n")

cat("Enrollment Parameters:\n")
cat("- Months 1-6:  ", round(fit$gamma[1], 1), " patients/month\n")
cat("- Months 7-18: ", round(fit$gamma[2], 1), " patients/month\n")
cat("- Months 19-24:", round(fit$gamma[3], 1), " patients/month\n")
cat("Total Enrollment Duration: 24 months\n")
cat("Total Sample Size (N):    ", ceiling(sum(fit$gamma * fit$R)), "\n\n")

cat("Analysis Schedule:\n")
cat("------------------------------------------------\n")
cat("Interim Analysis (40% events):\n")
cat("  - Timing:       Month ", round(fit$T[1], 1), "\n")
cat("  - Expected Events: ", round(fit$n.I[1], 1), "\n")
cat("  - Efficacy Bound (Z): ", round(fit$upper$bound[1], 3), " (p ≈ ", round(pnorm(-fit$upper$bound[1]), 5), ")\n")
cat("  - Futility Bound (Z): ", round(fit$lower$bound[1], 3), "\n\n")

cat("Final Analysis:\n")
cat("  - Timing:       Month ", round(fit$T[2], 1), " (12 months follow-up)\n")
cat("  - Expected Events: ", round(fit$n.I[2], 1), "\n")
cat("  - Efficacy Bound (Z): ", round(fit$upper$bound[2], 3), "\n")
cat("------------------------------------------------\n\n")

cat("Dropout Rate: 1% per month\n")
sink()

print(fit)
cat("\nInterim Analysis Time:", round(fit$T[1], 1), "months\n")

png("/tmp/benchmark_github-issue-38/agent_B/output_B/design_plot.png", width=800, height=600)
plot(fit)
dev.off()
