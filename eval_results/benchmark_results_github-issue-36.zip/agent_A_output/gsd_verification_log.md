# GSD Verification Log
**Design**: RAS WT Enrichment
**Date**: 2026-04-21

| Metric | Calculated | Simulated | Pass? |
|--------|-----------|-----------|-------|
| Power | 90.1% | 89.1% | PASS |
| Alpha | 0.0250 | 0.0250 | PASS |
