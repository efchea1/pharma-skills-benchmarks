library(gsDesign)
library(jsonlite)

# 1. Inputs & Assumptions
alpha <- 0.025
power_target <- 0.90
ratio <- 1
prev_wt <- 0.45
prev_mut <- 0.55
n_stage1 <- 200
n_stage2 <- 150
total_n <- n_stage1 + n_stage2
total_n_wt <- 90 + 150
total_n_itt <- 350
median_ctrl <- 8
hr_wt <- 0.65
hr_mut <- 1.0
lambda_ctrl <- log(2) / median_ctrl
lambda_wt <- lambda_ctrl * hr_wt
lambda_mut <- lambda_ctrl * hr_mut
enroll_rate <- 15
eta <- -log(1 - 0.05) / 12

# 2. Event Probability
calc_events <- function(T_cal, n, rate, start_time, hazard_c, hazard_e, eta, ratio=1) {
  end_time <- start_time + n / rate
  if (T_cal <= start_time) return(0)
  pts <- seq(start_time, min(T_cal, end_time), length.out = 100)
  dt <- pts[2] - pts[1]
  events <- 0
  for (p in pts) {
    fup <- T_cal - p
    prob_c <- (hazard_c / (hazard_c + eta)) * (1 - exp(-(hazard_c + eta) * fup))
    prob_e <- (hazard_e / (hazard_e + eta)) * (1 - exp(-(hazard_e + eta) * fup))
    events <- events + (rate / (1 + ratio)) * prob_c * dt + (rate * ratio / (1 + ratio)) * prob_e * dt
  }
  return(events)
}

z_alpha <- qnorm(1 - alpha)
z_beta <- qnorm(power_target)
target_events_wt <- ceiling(4 * (z_alpha + z_beta)^2 / log(hr_wt)^2)
cat(sprintf("Target WT Events: %d\n", target_events_wt))

find_fa_time <- function(target) {
  f <- function(t) {
    e1 <- calc_events(t, 90, enroll_rate * prev_wt, 0, lambda_ctrl, lambda_wt, eta)
    e2 <- calc_events(t, 150, enroll_rate, n_stage1 / enroll_rate, lambda_ctrl, lambda_wt, eta)
    return(e1 + e2 - target)
  }
  uniroot(f, c(1, 500))$root
}

fa_time <- find_fa_time(target_events_wt)
ia_time <- n_stage1 / enroll_rate + 3 

ia_events_wt <- calc_events(ia_time, 90, enroll_rate * prev_wt, 0, lambda_ctrl, lambda_wt, eta)
fa_events_wt <- calc_events(fa_time, 90, enroll_rate * prev_wt, 0, lambda_ctrl, lambda_wt, eta) +
                calc_events(fa_time, 150, enroll_rate, n_stage1 / enroll_rate, lambda_ctrl, lambda_wt, eta)

ia_events_mut <- calc_events(ia_time, 110, enroll_rate * prev_mut, 0, lambda_ctrl, lambda_mut, eta)
fa_events_mut <- calc_events(fa_time, 110, enroll_rate * prev_mut, 0, lambda_ctrl, lambda_mut, eta)

ia_events_itt <- ia_events_wt + ia_events_mut
fa_events_itt <- fa_events_wt + fa_events_mut

cat(sprintf("IA Time: %.1f, IA WT Events: %.1f, IA ITT Events: %.1f\n", ia_time, ia_events_wt, ia_events_itt))
cat(sprintf("FA Time: %.1f, FA WT Events: %.1f, FA ITT Events: %.1f\n", fa_time, fa_events_wt, fa_events_itt))

# 3. Boundaries & Power
delta_wt <- log(1 / hr_wt) / 2
gs_wt <- gsDesign(k=2, test.type=1, alpha=alpha, n.I=c(ia_events_wt, fa_events_wt), 
                 maxn.IPlan=fa_events_wt, sfu=sfLDOF, delta=delta_wt, delta1=delta_wt, delta0=0)

p_wt_fa <- fa_events_wt / fa_events_itt
p_mut_fa <- fa_events_mut / fa_events_itt
hr_itt_fa <- hr_wt * p_wt_fa + hr_mut * p_mut_fa

delta_itt <- log(1 / hr_itt_fa) / 2
gs_itt_pwr <- gsDesign(k=2, test.type=1, alpha=alpha, n.I=c(ia_events_itt, fa_events_itt), 
                      maxn.IPlan=fa_events_itt, sfu=sfLDOF, delta=delta_itt, delta1=delta_itt, delta0=0)

# Export
results <- list(
  design_name = "Phase 3 CRC Enrichment Design",
  populations = list(
    list(name = "RAS WT (Primary)", N = total_n_wt, events = fa_events_wt, hr = hr_wt, power = sum(gs_wt$upper$prob[,2])),
    list(name = "ITT (Secondary)", N = total_n_itt, events = fa_events_itt, hr = hr_itt_fa, power = sum(gs_itt_pwr$upper$prob[,2]))
  ),
  analyses = list(
    list(name = "IA", time = ia_time, wt_events = ia_events_wt, itt_events = ia_events_itt, 
         wt_bound_z = gs_wt$upper$bound[1], wt_bound_hr = exp(-gs_wt$upper$bound[1]*2/sqrt(ia_events_wt))),
    list(name = "FA", time = fa_time, wt_events = fa_events_wt, itt_events = fa_events_itt, 
         wt_bound_z = gs_wt$upper$bound[2], wt_bound_hr = exp(-gs_wt$upper$bound[2]*2/sqrt(fa_events_wt)))
  ),
  n_wt = total_n_wt,
  n_itt = total_n_itt,
  target_power_wt = power_target,
  alpha = alpha
)
write_json(results, "/tmp/benchmark_github-issue-36/agent_A/output_A/gsd_results.json", auto_unbox = TRUE, pretty = TRUE)

cat("Design Summary:\n")
cat(sprintf("WT Power: %.1f%%\n", sum(gs_wt$upper$prob[,2])*100))
cat(sprintf("ITT Power: %.1f%%\n", sum(gs_itt_pwr$upper$prob[,2])*100))
