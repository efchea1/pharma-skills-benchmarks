library(lrstat)
library(jsonlite)

res <- read_json("/tmp/benchmark_github-issue-36/agent_A/output_A/gsd_results.json")

# RAS WT verification
# Stage 1: 90 patients, Stage 2: 150 patients
accrualTime <- c(0, 13.33)
accrualIntensity <- c(6.75, 15)
n_wt <- 240

# hazards
median_ctrl <- 8
hr_wt <- 0.65
lambda2 <- log(2) / median_ctrl
lambda1 <- lambda2 * hr_wt
eta <- -log(1 - 0.05) / 12

# Boundaries (Z)
z_upper <- c(res$analyses[[1]]$wt_bound_z, res$analyses[[2]]$wt_bound_z)
planned_events <- c(res$analyses[[1]]$wt_events, res$analyses[[2]]$wt_events)

# Simulation H1
sim_h1 <- lrsim(
  kMax = 2,
  criticalValues = z_upper,
  futilityBounds = rep(-6, 1),
  allocation1 = 1, allocation2 = 1,
  accrualTime = accrualTime,
  accrualIntensity = accrualIntensity,
  n = n_wt,
  lambda1 = lambda1,
  lambda2 = lambda2,
  gamma1 = eta, gamma2 = eta,
  plannedEvents = planned_events,
  maxNumberOfIterations = 5000,
  seed = 12345
)

# Simulation H0
sim_h0 <- lrsim(
  kMax = 2,
  criticalValues = z_upper,
  futilityBounds = rep(-6, 1),
  allocation1 = 1, allocation2 = 1,
  accrualTime = accrualTime,
  accrualIntensity = accrualIntensity,
  n = n_wt,
  lambda1 = lambda2, # HR=1
  lambda2 = lambda2,
  gamma1 = eta, gamma2 = eta,
  plannedEvents = planned_events,
  maxNumberOfIterations = 5000,
  seed = 54321
)

cat("Verification Results (RAS WT):\n")
cat(sprintf("Simulated Power: %.1f%%\n", sim_h1$overview$overallReject * 100))
cat(sprintf("Simulated Alpha: %.4f\n", sim_h0$overview$overallReject))

# Save log
log_lines <- c(
  "# GSD Verification Log",
  sprintf("**Design**: RAS WT Enrichment"),
  sprintf("**Date**: %s", Sys.Date()),
  "",
  "| Metric | Calculated | Simulated | Pass? |",
  "|--------|-----------|-----------|-------|",
  sprintf("| Power | %.1f%% | %.1f%% | %s |", res$populations[[1]]$power * 100, sim_h1$overview$overallReject * 100, ifelse(abs(sim_h1$overview$overallReject - res$populations[[1]]$power) < 0.02, "PASS", "FAIL")),
  sprintf("| Alpha | %.4f | %.4f | %s |", res$alpha, sim_h0$overview$overallReject, ifelse(abs(sim_h0$overview$overallReject - res$alpha) < 0.005, "PASS", "FAIL"))
)
writeLines(log_lines, "/tmp/benchmark_github-issue-36/agent_A/output_A/gsd_verification_log.md")
