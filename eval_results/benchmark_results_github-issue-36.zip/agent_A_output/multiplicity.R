library(graphicalMCP)

# Fixed sequence H1 -> H2
hyp_names <- c("H1\nRAS WT", "H2\nITT")
hyp_alpha <- c(0.025, 0.0)
m <- matrix(c(0, 1,
              0, 0), nrow = 2, byrow = TRUE)
g <- graph_create(hyp_alpha, m)

png("/tmp/benchmark_github-issue-36/agent_A/output_A/multiplicity_diagram.png", width=800, height=600, res=100)
plot(g, hyp_names = hyp_names, precision = 4)
dev.off()
