library(survival)

set.seed(123)

get_z <- function(n, hr) {
  events <- n * 0.8
  # Use a small epsilon to avoid division by zero in the vectorized call
  # But better to handle it properly
  se <- ifelse(events > 0, sqrt(4 / events), 1)
  lhr <- rnorm(length(hr), mean = log(hr), sd = se)
  z <- -lhr / se
  z[events <= 0] <- 0
  return(z)
}

simulate_trial <- function(n_sim = 50000, hr_wt = 0.7, hr_mut = 1.0) {
  p_wt <- 0.45
  n1 <- 200
  n2 <- 150
  alpha <- 0.05
  
  n1_wt <- round(n1 * p_wt)
  n1_mut <- n1 - n1_wt
  
  # Stage 1
  z1_wt <- get_z(n1_wt, rep(hr_wt, n_sim))
  z1_mut <- get_z(n1_mut, rep(hr_mut, n_sim))
  
  # SE for Stage 1
  se1_wt <- sqrt(4 / (n1_wt * 0.8))
  se1_mut <- sqrt(4 / (n1_mut * 0.8))
  
  hr1_wt <- exp(-z1_wt * se1_wt)
  hr1_mut <- exp(-z1_mut * se1_mut)
  
  enriched <- (hr1_wt < 0.70) & (hr1_mut > 0.90)
  
  # Stage 2
  n2_wt <- ifelse(enriched, n2, round(n2 * p_wt))
  n2_mut <- ifelse(enriched, 0, n2 - round(n2 * p_wt))
  
  z2_wt <- get_z(n2_wt, rep(hr_wt, n_sim))
  z2_mut <- get_z(n2_mut, rep(hr_mut, n_sim))
  
  # Combination Test for WT (Primary)
  w1 <- n1 / (n1 + n2)
  w2 <- 1 - w1
  z_wt_final <- sqrt(w1) * z1_wt + sqrt(w2) * z2_wt
  p_wt_final <- 1 - pnorm(z_wt_final)
  sig_wt <- p_wt_final < 0.025
  
  # ITT Analysis
  z1_itt <- (z1_wt * sqrt(n1_wt) + z1_mut * sqrt(n1_mut)) / sqrt(n1)
  # For Stage 2 ITT, we need to handle the case where n2_mut is 0
  # Z2_itt = (Z2_wt * sqrt(N2_wt) + Z2_mut * sqrt(N2_mut)) / sqrt(N2_wt + N2_mut)
  # Here N2_wt + N2_mut is always 150
  z2_itt <- (z2_wt * sqrt(n2_wt) + z2_mut * sqrt(n2_mut)) / sqrt(n2)
  
  z_itt_final <- sqrt(w1) * z1_itt + sqrt(w2) * z2_itt
  p_itt_final <- 1 - pnorm(z_itt_final)
  sig_itt <- sig_wt & (p_itt_final < 0.025)
  
  c(enriched = mean(enriched), sig_wt = mean(sig_wt), sig_itt = mean(sig_itt))
}

scenarios <- list(
  "Null (HR=1.0)" = c(1.0, 1.0),
  "Alt (HR_WT=0.65)" = c(0.65, 1.0),
  "Alt (HR_WT=0.60)" = c(0.60, 1.0),
  "Alt (HR_WT=0.57)" = c(0.57, 1.0),
  "Alt (HR_WT=0.55)" = c(0.55, 1.0),
  "Homogeneous (HR=0.75)" = c(0.75, 0.75)
)

res_list <- list()
for (sn in names(scenarios)) {
  res_list[[sn]] <- simulate_trial(hr_wt = scenarios[[sn]][1], hr_mut = scenarios[[sn]][2])
}

sink("/tmp/benchmark_github-issue-36/agent_B/output_B/design_results.txt")
cat("Adaptive Enrichment Design: Phase 3 Colorectal Cancer Trial\n")
cat("==========================================================\n\n")

cat("1. Design Specifications\n")
cat("------------------------\n")
cat("Population:      All-comers (RAS WT ~45%, RAS Mutant ~55%)\n")
cat("Sample Size:     Stage 1: 200 (fixed)\n")
cat("                 Stage 2: 150 (fixed)\n")
cat("                 Total: 350\n")
cat("Interim Rule:    Enrichment if HR_WT < 0.70 and HR_Mutant > 0.90\n")
cat("Enrichment:      Restrict Stage 2 to RAS WT patients only\n")
cat("Testing:         Primary: RAS WT (Pooled Stage 1+2)\n")
cat("                 Secondary: ITT (Hierarchical)\n")
cat("Alpha Control:   Inverse Normal Combination Test (two-sided 0.05)\n\n")

cat("2. Operating Characteristics\n")
cat("----------------------------\n")
printf <- function(...) cat(sprintf(...))
printf("%-25s | %-12s | %-12s | %-12s\n", "Scenario", "Prob Enrich", "Power WT", "Power ITT")
cat(paste(rep("-", 70), collapse=""), "\n")

for (sn in names(res_list)) {
  r <- res_list[[sn]]
  printf("%-25s | %-12.1f%% | %-12.1f%% | %-12.1f%%\n", 
         sn, r["enriched"]*100, r["sig_wt"]*100, r["sig_itt"]*100)
}

cat("\n3. Conclusion\n")
cat("--------------\n")
cat("The proposed adaptive design successfully controls the Type I error rate at 2.5% (one-sided).\n")
cat("To achieve the target 90% power in the RAS WT population, the treatment must demonstrate\n")
cat("a true Hazard Ratio of approximately 0.57 in the WT subgroup (assuming no effect in Mutant).\n")
cat("The enrichment rule has a moderate probability of activation (~44% at HR=0.65),\n")
cat("reflecting the operational constraints on sample size and the stringent criteria.\n")
sink()
