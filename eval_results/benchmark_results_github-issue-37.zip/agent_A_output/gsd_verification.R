library(lrstat)
library(jsonlite)

# Load design results
res <- read_json("/tmp/benchmark_github-issue-37/agent_A/output_A/gsd_results.json")

# Parameters
n_pts <- res$design_params$enroll_n
enroll_dur <- res$design_params$enroll_duration
gamma <- n_pts / enroll_dur
lambdaC <- log(2) / res$design_params$control_median
hr <- res$design_params$hr_target
lambdaE <- lambdaC * hr
eta <- -log(1 - res$design_params$annual_dropout) / 12

ia_events <- res$analysis_plan$ia_events
fa_events <- res$analysis_plan$fa_events
eff_z <- res$boundaries$efficacy$z

# Verification Simulation (H1)
set.seed(123)
sim_h1 <- lrsim(
  kMax = 2,
  criticalValues = eff_z,
  futilityBounds = rep(-6, 1), # Non-binding, so we ignore futility for power verification
  allocation1 = 1, allocation2 = 1,
  accrualTime = 0, accrualIntensity = gamma,
  accrualDuration = enroll_dur,
  piecewiseSurvivalTime = 0,
  lambda1 = lambdaE,
  lambda2 = lambdaC,
  gamma1 = eta, gamma2 = eta,
  plannedEvents = c(ia_events, fa_events),
  maxNumberOfIterations = 10000
)

# Verification Simulation (H0)
set.seed(456)
sim_h0 <- lrsim(
  kMax = 2,
  criticalValues = eff_z,
  futilityBounds = rep(-6, 1),
  allocation1 = 1, allocation2 = 1,
  accrualTime = 0, accrualIntensity = gamma,
  accrualDuration = enroll_dur,
  piecewiseSurvivalTime = 0,
  lambda1 = lambdaC, # HR = 1
  lambda2 = lambdaC,
  gamma1 = eta, gamma2 = eta,
  plannedEvents = c(ia_events, fa_events),
  maxNumberOfIterations = 10000
)

# Extract metrics
# sim_h1$overview$overallReject is the power
# sim_h1$overview$numberOfEvents is a vector of mean events
# sim_h1$overview$analysisTime is a vector of mean times

verif_res <- list(
  h1 = list(
    power = sim_h1$overview$overallReject,
    events = sim_h1$overview$numberOfEvents,
    times = sim_h1$overview$analysisTime
  ),
  h0 = list(
    alpha = sim_h0$overview$overallReject
  )
)

write_json(verif_res, "/tmp/benchmark_github-issue-37/agent_A/output_A/gsd_verification.json", auto_unbox = TRUE, pretty = TRUE)

# Print log
cat("# GSD Verification Log\n")
cat(sprintf("Power (Calculated: %.1f%%, Simulated: %.1f%%)\n", res$power_actual * 100, verif_res$h1$power * 100))
cat(sprintf("Type I Error (Calculated: %.1f%%, Simulated: %.1f%%)\n", res$design_params$alpha_1sided * 100, verif_res$h0$alpha * 100))
cat(sprintf("Events IA (Calculated: %.1f, Simulated: %.1f)\n", ia_events, verif_res$h1$events[1]))
cat(sprintf("Events FA (Calculated: %.1f, Simulated: %.1f)\n", fa_events, verif_res$h1$events[2]))
cat(sprintf("Timing IA (Calculated: %.1f, Simulated: %.1f)\n", res$analysis_plan$ia_time, verif_res$h1$times[1]))
cat(sprintf("Timing FA (Calculated: %.1f, Simulated: %.1f)\n", res$analysis_plan$fa_time, verif_res$h1$times[2]))
