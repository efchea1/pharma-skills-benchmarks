library(gsDesign)
library(jsonlite)

# --- Parameters ---
alpha <- 0.025
power_target <- 0.90
hr <- 0.65
ctrl_median <- 12
lambdaC <- log(2) / ctrl_median
eta <- -log(1 - 0.05) / 12
ratio <- 1
n_pts <- 450
enroll_dur <- 24
gamma <- n_pts / enroll_dur
R_vec <- enroll_dur

# IA
ia_fraction <- 0.40
sfu <- sfLDOF
sfl <- sfHSD
sflpar <- -20

# Helper function
calc_expected_events <- function(T_cal, lambdaC, hr, eta, gamma_vec, R_vec, ratio_val) {
  lambda_exp <- lambdaC * hr
  enroll_starts <- c(0, cumsum(R_vec[-length(R_vec)]))
  enroll_ends   <- cumsum(R_vec)
  total_events <- 0
  for (i in seq_along(gamma_vec)) {
    s_start <- enroll_starts[i]
    s_end   <- min(enroll_ends[i], T_cal)
    if (s_start >= T_cal) next
    rate <- gamma_vec[i]
    dur <- s_end - s_start
    fup_end   <- T_cal - s_end
    fup_start <- T_cal - s_start
    haz_ctrl <- lambdaC + eta
    cr_ctrl  <- lambdaC / haz_ctrl
    int_ctrl <- dur - (exp(-haz_ctrl * fup_end) - exp(-haz_ctrl * fup_start)) / haz_ctrl
    events_ctrl <- rate * (1 / (1 + ratio_val)) * cr_ctrl * int_ctrl
    haz_exp <- lambda_exp + eta
    cr_exp  <- lambda_exp / haz_exp
    int_exp <- dur - (exp(-haz_exp * fup_end) - exp(-haz_exp * fup_start)) / haz_exp
    events_exp <- rate * (ratio_val / (1 + ratio_val)) * cr_exp * int_exp
    total_events <- total_events + events_ctrl + events_exp
  }
  total_events
}

events_at_enroll_end <- calc_expected_events(24, lambdaC, hr, eta, gamma, R_vec, ratio)

# Create design
x_final <- gsSurv(
  k = 2, test.type = 4, alpha = alpha, beta = 1 - power_target,
  timing = ia_fraction, sfu = sfu, sfl = sfl, sflpar = sflpar,
  lambdaC = lambdaC, hr = hr, eta = eta,
  gamma = gamma, R = R_vec, T = NULL, minfup = NULL, ratio = ratio
)

sum_res <- gsBoundSummary(x_final)

# Power extraction
# Probabilities under H1 are in x_final$gs$upper$prob evaluated at theta[2]
power <- sum(x_final$upper$prob[, 2]) # Wait, let's verify if column 2 is H1

results <- list(
  design_params = list(
    alpha_1sided = alpha,
    power_target = power_target,
    hr_target = hr,
    control_median = ctrl_median,
    enroll_n = n_pts,
    enroll_duration = enroll_dur,
    annual_dropout = 0.05
  ),
  analysis_plan = list(
    ia_events = x_final$n.I[1],
    ia_time = x_final$T[1],
    fa_events = x_final$n.I[2],
    fa_time = x_final$T[2],
    events_at_enroll_end = events_at_enroll_end
  ),
  boundaries = list(
    efficacy = list(
      z = x_final$upper$bound,
      hr = as.numeric(gsub("[<> ]", "", sum_res[sum_res$Value == "HR at bound", "Upper"]))
    ),
    futility = list(
      z = x_final$lower$bound,
      hr = as.numeric(gsub("[<> ]", "", sum_res[sum_res$Value == "HR at bound", "Lower"]))
    )
  ),
  power_actual = power
)

write_json(results, "/tmp/benchmark_github-issue-37/agent_A/output_A/gsd_results.json", auto_unbox = TRUE, pretty = TRUE)

cat(sprintf("Events at enrollment end: %.1f\n", events_at_enroll_end))
cat(sprintf("Target IA events: %.1f\n", x_final$n.I[1]))
cat(sprintf("IA month: %.1f\n", x_final$T[1]))
