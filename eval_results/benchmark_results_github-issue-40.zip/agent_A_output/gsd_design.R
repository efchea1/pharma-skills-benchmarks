library(gsDesign)
library(jsonlite)

# --- Assumptions ---
alpha_total <- 0.025  
power_target <- 0.90 

prev_sub <- 0.40      
median_itt_ctrl <- 18
median_sub_ctrl <- 15
hr_itt <- 0.78
hr_sub <- 0.65
ratio <- 1
dropout_annual <- 0.05
eta <- -log(1 - dropout_annual) / 12

gamma_total <- 20
N_target <- 600

x_itt_ref <- gsSurv(
  k = 2, test.type = 1, alpha = alpha_total, beta = 1 - power_target,
  timing = 0.5, sfu = sfLDOF,
  lambdaC = log(2)/median_itt_ctrl, hr = hr_itt, eta = eta,
  gamma = 20, R = 100, T = NULL, minfup = 12, ratio = ratio
)

final_N <- max(N_target, ceiling(sum(x_itt_ref$gamma * x_itt_ref$R) / 10) * 10)
R_final <- final_N / 20

x_itt <- gsSurv(
  k = 2, test.type = 1, alpha = alpha_total, beta = 1 - power_target,
  timing = 0.5, sfu = sfLDOF,
  lambdaC = log(2)/median_itt_ctrl, hr = hr_itt, eta = eta,
  gamma = 20, R = R_final, T = NULL, minfup = NULL, ratio = ratio
)

fa_time <- x_itt$T[2]
events_itt <- x_itt$n.I

# Correct power extraction
itt_power <- sum(x_itt$upper$prob)

# Subgroup calculations
calc_expected_events <- function(T_cal, lambdaC, hr, eta, gamma_vec, R_vec, ratio_val) {
  lambdaE <- lambdaC * hr
  total_events <- 0
  n_pts <- 500
  rate <- gamma_vec
  enroll_dur <- R_vec
  
  s_start <- 0
  s_end <- min(enroll_dur, T_cal)
  if (s_start >= T_cal) return(0)
  
  dt <- (s_end - s_start) / n_pts
  for (k in 1:n_pts) {
    et <- s_start + (k - 0.5) * dt
    fup <- T_cal - et
    ep_ctrl <- (lambdaC / (lambdaC + eta)) * (1 - exp(-(lambdaC + eta) * fup))
    ep_exp <- (lambdaE / (lambdaE + eta)) * (1 - exp(-(lambdaE + eta) * fup))
    total_events <- total_events + 
      rate * (1 / (1 + ratio_val)) * ep_ctrl * dt +
      rate * (ratio_val / (1 + ratio_val)) * ep_exp * dt
  }
  total_events
}

events_sub_m18 <- calc_expected_events(18, log(2)/median_sub_ctrl, hr_sub, eta, 20 * prev_sub, R_final, ratio)
events_sub_fa <- calc_expected_events(fa_time, log(2)/median_sub_ctrl, hr_sub, eta, 20 * prev_sub, R_final, ratio)

delta_sub <- log(1/hr_sub) / 2
z_final <- qnorm(1 - alpha_total)

d_pwr <- gsProbability(
  k = 2, theta = delta_sub * sqrt(events_sub_fa), n.I = c(events_sub_m18, events_sub_fa),
  a = c(0.5, -20), b = c(20, z_final)
)
power_sub <- sum(d_pwr$upper$prob)

res <- list(
  N = final_N,
  enrollment_duration = R_final,
  itt = list(
    events = events_itt,
    timing = x_itt$T,
    z_bounds = x_itt$upper$bound,
    hr_bounds = exp(-x_itt$upper$bound * 2 / sqrt(events_itt)),
    power = itt_power
  ),
  subgroup = list(
    prevalence = prev_sub,
    events = c(events_sub_m18, events_sub_fa),
    timing = c(18, fa_time),
    z_bounds_eff = c(20, z_final),
    z_bounds_fut = c(0.5, -20),
    power = power_sub
  )
)
write_json(res, "/tmp/benchmark_github-issue-40/agent_A/output_A/gsd_results.json", auto_unbox = TRUE, pretty = TRUE)
cat(sprintf("Final N: %d\n", final_N))
cat(sprintf("ITT Power: %.2f%%\n", res$itt$power * 100))
cat(sprintf("Subgroup Power: %.2f%%\n", res$subgroup$power * 100))
