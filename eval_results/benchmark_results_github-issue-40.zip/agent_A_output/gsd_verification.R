library(lrstat)
library(jsonlite)

res <- read_json("/tmp/benchmark_github-issue-40/agent_A/output_A/gsd_results.json")
N <- as.numeric(res$N)
D <- N / 20

# H4: ITT Verification
sim_itt_h1 <- lrsim(
  kMax = 2,
  criticalValues = as.numeric(unlist(res$itt$z_bounds)),
  futilityBounds = rep(-6, 1),
  allocation1 = 1, allocation2 = 1,
  accrualTime = c(0, D),
  accrualIntensity = c(20, 0),
  n = N,
  piecewiseSurvivalTime = 0,
  lambda1 = (log(2)/18) * 0.78,
  lambda2 = log(2)/18,
  gamma1 = -log(1-0.05)/12, gamma2 = -log(1-0.05)/12,
  plannedEvents = as.numeric(unlist(res$itt$events)),
  maxNumberOfIterations = 5000, seed = 123
)

# H3: Subgroup Verification
sim_sub_h1 <- lrsim(
  kMax = 2,
  criticalValues = as.numeric(unlist(res$subgroup$z_bounds_eff)),
  futilityBounds = as.numeric(unlist(res$subgroup$z_bounds_fut))[1],
  allocation1 = 1, allocation2 = 1,
  accrualTime = c(0, D),
  accrualIntensity = c(20 * 0.4, 0),
  n = N * 0.4,
  piecewiseSurvivalTime = 0,
  lambda1 = (log(2)/15) * 0.65,
  lambda2 = log(2)/15,
  gamma1 = -log(1-0.05)/12, gamma2 = -log(1-0.05)/12,
  plannedEvents = as.numeric(unlist(res$subgroup$events)),
  maxNumberOfIterations = 5000, seed = 456
)

verification_results <- list(
  itt_power_sim = sim_itt_h1$overview$overallReject,
  sub_power_sim = sim_sub_h1$overview$overallReject
)
write_json(verification_results, "/tmp/benchmark_github-issue-40/agent_A/output_A/gsd_verification.json", auto_unbox = TRUE, pretty = TRUE)
print(verification_results)
