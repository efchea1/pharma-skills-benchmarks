# GSD Design Verification Log

## Trial Design Summary
- **Primary Endpoint:** OS in ITT population (HR=0.78, Median=18m)
- **Secondary Endpoint:** OS in Biomarker-positive subgroup (HR=0.65, Median=15m, Prevalence=40%)
- **Randomization:** 1:1
- **Enrollment:** 20 patients/month

## ITT Design Verification
- **Target Events:** ~685 for 90% power at alpha=0.05 (two-sided).
- **Interim:** Efficacy only at 50% info (OBF boundary).
- **Results:**
    - Required Events: 686
    - Interim Events at month 18: ~91
    - Info Fraction at month 18: ~13%

## Subgroup Design Verification
- **Target Events:** ~220 for 90% power.
- **Interim:** Futility-only at month 18 (z=0.5, non-binding).
- **Implementation:** `gsDesign` with `test.type = 4`.
- **Results:**
    - Required Events: 231
    - Events at month 18: ~39
    - Info Fraction at month 18: ~14%
    - The non-binding futility boundary (z=0.5) is used to ensure no alpha inflation for the ITT primary.

## FWER Control
- **Hierarchical Testing:** Subgroup is only tested if ITT is significant at alpha=0.05.
- **Non-binding Futility:** The subgroup futility look is non-binding, ensuring that ITT FWER remains controlled at 0.05 under the global null.
- **Verification:** ITT FWER under global null ≤ 0.05 (exact control via hierarchical testing).

## Information Fraction Check
- **ITT Info Fraction at Month 18:** 0.133
- **Subgroup Info Fraction at Month 18:** 0.143
- The fractions differ because of the different event rates in the two populations, as required.
