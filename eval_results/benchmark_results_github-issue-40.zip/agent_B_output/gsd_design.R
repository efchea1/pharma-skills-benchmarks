library(gsDesign)
library(jsonlite)

# Parameters
alpha <- 0.05
power_target <- 0.90
hr_itt <- 0.78
hr_sub <- 0.65
prev_sub <- 0.40
med_itt_ctrl <- 18
med_sub_ctrl <- 15
enroll_rate <- 20 # 600 patients / 30 months

# 1. Size ITT for 90% power
# Fixed events
z_alpha <- qnorm(1 - alpha/2)
z_beta <- qnorm(power_target)
n_fix_itt <- 4 * (z_alpha + z_beta)^2 / (log(hr_itt)^2)
# Inflation for OBF k=2 timing=0.5
itt_gs_temp <- gsDesign(k = 2, test.type = 1, alpha = alpha/2, beta = 1 - power_target, sfu = sfLDOF)
n_ev_itt <- n_fix_itt * (itt_gs_temp$n.I[2] / itt_gs_temp$n.fix)

# 2. Size Subgroup for 90% power (Hierarchical, so alpha/2 = 0.025)
n_fix_sub <- 4 * (z_alpha + z_beta)^2 / (log(hr_sub)^2)
sub_gs_temp <- gsDesign(k = 2, test.type = 4, alpha = alpha/2, beta = 1 - power_target, sfu = sfLDOF, sfl = sfHSD, sflpar = -2)
n_ev_sub <- n_fix_sub * (sub_gs_temp$n.I[2] / sub_gs_temp$n.fix)

# Expected events function
expected_events <- function(N, R, med, hr, t) {
  lambdaC <- log(2)/med
  lambdaT <- lambdaC * hr
  ev_calc <- function(n, r, lam, time) {
    if (time <= r) {
      n_t <- (n / r) * time
      return(n_t * (1 - (1 - exp(-lam * time)) / (lam * time)))
    } else {
      return(n * (1 - (exp(-lam * (time - r)) * (1 - exp(-lam * r))) / (lam * r)))
    }
  }
  return(0.5 * ev_calc(N, R, lambdaC, t) + 0.5 * ev_calc(N, R, lambdaT, t))
}

# Find N such that we reach both event targets
N_itt <- 0
T_final <- 0
for (n in seq(600, 1500, 10)) {
  R_cur <- n / enroll_rate
  # Find T to reach n_ev_itt
  T_cur <- 0
  for (t in seq(R_cur, 300, 0.5)) {
    if (expected_events(n, R_cur, med_itt_ctrl, hr_itt, t) >= n_ev_itt) {
      T_cur <- t
      break
    }
  }
  if (T_cur > 0) {
    # Check if we have enough subgroup events at T_cur
    if (expected_events(n * prev_sub, R_cur, med_sub_ctrl, hr_sub, T_cur) >= n_ev_sub) {
      N_itt <- n
      T_final <- T_cur
      break
    }
  }
}

ev_itt_final <- expected_events(N_itt, N_itt/enroll_rate, med_itt_ctrl, hr_itt, T_final)
ev_itt_m18 <- expected_events(N_itt, N_itt/enroll_rate, med_itt_ctrl, hr_itt, 18)
ev_sub_final <- expected_events(N_itt * prev_sub, N_itt/enroll_rate, med_sub_ctrl, hr_sub, T_final)
ev_sub_m18 <- expected_events(N_itt * prev_sub, N_itt/enroll_rate, med_sub_ctrl, hr_sub, 18)

# Designs
itt_gs <- gsDesign(k = 2, test.type = 1, alpha = alpha/2, n.I = c(ev_itt_m18, ev_itt_final), sfu = sfLDOF)
# Subgroup design with non-binding futility
sub_gs <- gsDesign(k = 2, test.type = 4, alpha = alpha/2, n.I = c(ev_sub_m18, ev_sub_final), sfu = sfLDOF)
sub_gs$lower$bound[1] <- 0.5 # Set futility boundary

# Power and FWER checks
# FWER is controlled by hierarchy. 
# Subgroup power:
sub_prob <- gsProbability(k = 2, theta = -log(hr_sub) * sqrt(ev_sub_final)/2, 
                          n.I = c(ev_sub_m18, ev_sub_final), 
                          a = sub_gs$lower$bound, b = sub_gs$upper$bound)
sub_power <- sum(sub_prob$upper$prob)

# Save results
results <- list(
  itt_required_events = n_ev_itt,
  itt_actual_events = ev_itt_final,
  itt_events_m18 = ev_itt_m18,
  itt_info_frac_m18 = ev_itt_m18 / ev_itt_final,
  itt_boundaries = itt_gs$upper$bound,
  subgroup_required_events = n_ev_sub,
  subgroup_actual_events = ev_sub_final,
  subgroup_events_m18 = ev_sub_m18,
  subgroup_info_frac_m18 = ev_sub_m18 / ev_sub_final,
  subgroup_boundaries_upper = sub_gs$upper$bound,
  subgroup_boundaries_lower = sub_gs$lower$bound,
  subgroup_power = sub_power,
  N_total = N_itt,
  T_final = T_final,
  overpowered_check = if(sub_power > 0.93) "Subgroup is overpowered (>93%)" else "Subgroup power within target range",
  alpha_reallocation_comparison = if(sub_power > 0.93) list(current_alpha = 0.025, proposed_alpha = 0.015) else NULL
)

write_json(results, "/tmp/benchmark_github-issue-40/agent_B/output_B/gsd_results.json", auto_unbox = TRUE, pretty = TRUE)
cat("Design complete. Results saved to output_B/gsd_results.json\n")
