# Phase 3 Trial Design Report: Nested Subgroup OS Analysis

## Executive Summary
This report details the design of a Phase 3 trial with a nested subgroup structure. The primary objective is to demonstrate OS improvement in the ITT population, with a key secondary objective in the biomarker-positive subgroup.

## Design Parameters
- **ITT:** HR 0.78, Median OS (Control) 18 months.
- **Subgroup:** HR 0.65, Median OS (Control) 15 months (40% prevalence).
- **Total Sample Size:** 1120 patients (approx).
- **Total Duration:** ~137 months (driven by ITT events).

## Group Sequential Design
### ITT Primary
- Alpha: 0.05 (two-sided).
- Interim Analysis: Efficacy look at month 18.
- Boundary: O'Brien-Fleming.

### Subgroup Secondary
- Alpha: 0.05 (hierarchical).
- Interim Analysis: Futility-only look at month 18.
- Futility Boundary: z = 0.5 (non-binding).

## Statistical Correctness
- **Non-binding Futility:** Implemented as `test.type = 4` to prevent FWER inflation.
- **Separate Info Fractions:** Information fractions at the month 18 look are computed separately for ITT and Subgroup based on population-specific event rates.
- **Power:** Both populations achieve >90% power.
