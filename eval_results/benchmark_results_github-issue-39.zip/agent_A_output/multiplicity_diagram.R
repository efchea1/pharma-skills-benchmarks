library(graphicalMCP)
# Single hypothesis diagram
graph <- graph_create(hypotheses = 0.025)
# Set names
names(graph$hypotheses) <- "H1: CV Death"
# Plot
png("/tmp/benchmark_github-issue-39/agent_A/output_A/multiplicity_diagram.png", width=600, height=400)
plot(graph, precision = 4)
dev.off()
