library(gsDesign)
library(jsonlite)

# --- Parameters ---
alpha <- 0.025
beta <- 0.10
hr <- 0.80
ratio <- 1
total_n <- 9000
enroll_dur <- 48
control_annual_cv_death <- 0.025
non_cv_annual_death <- 0.02

# Convert annual rates to monthly hazards
lambda_cv <- -log(1 - control_annual_cv_death) / 12
eta <- -log(1 - non_cv_annual_death) / 12
gamma <- total_n / enroll_dur
R <- enroll_dur

# --- Design ---
x <- gsSurv(
  k = 2,
  test.type = 4, # Non-binding futility
  alpha = alpha,
  beta = beta,
  timing = 0.5,
  sfu = sfLDOF,
  sfl = sfHSD, sflpar = -20,
  lambdaC = lambda_cv,
  hr = hr,
  eta = eta,
  gamma = gamma,
  R = R,
  T = NULL,
  minfup = NULL,
  ratio = ratio
)

# Extract results for report
tab <- gsBoundSummary(x, deltaname = "HR", logdelta = TRUE, Nname = "Events", digits = 4, ddigits = 4, tdigits = 1)
tab_df <- as.data.frame(tab)

# Helper to extract from gsBoundSummary
extract_val <- function(row_name, col_name) {
  as.numeric(as.character(tab_df[which(tab_df$Value == row_name), col_name]))
}

results <- list(
  disease = "Cardiovascular Outcomes Trial (Phase 3)",
  endpoints = "Cardiovascular Death",
  randomization = "1:1",
  alpha = alpha,
  power_target = 0.9,
  total_N = total_n,
  N_per_arm = total_n / 2,
  enrollment_duration = enroll_dur,
  study_duration = x$T[2],
  ctrl_median_os = log(2) / lambda_cv,
  hr_os = hr,
  efficacy_spending = "Lan-DeMets O'Brien-Fleming",
  futility_type = "Non-binding",
  futility_spending = "Hwang-Shih-DeCani (gamma = -20)",
  dropout_annual = non_cv_annual_death,
  min_followup = x$T[2] - enroll_dur,
  min_gap = x$T[2] - x$T[1],
  
  # OS specific fields for the report
  os_z_upper = x$upper$bound,
  os_z_lower = x$lower$bound,
  os_hr_upper = exp(-x$upper$bound * 2 / sqrt(x$n.I)),
  os_hr_lower = exp(-x$lower$bound * 2 / sqrt(x$n.I)),
  os_p_upper = pnorm(-x$upper$bound),
  os_cum_power = x$upper$prob[, 2],
  os_cum_alpha = x$upper$prob[, 1],
  os_info_frac = x$n.I / max(x$n.I),
  os_N_at_analysis = rep(total_n, 2),
  events_ia = ceiling(x$n.I[1]),
  events_fa = ceiling(x$n.I[2]),
  ia_time = x$T[1],
  fa_time = x$T[2],
  os_power = sum(x$upper$prob[, 2])
)

write_json(results, "/tmp/benchmark_github-issue-39/agent_A/output_A/gsd_results.json", auto_unbox = TRUE, pretty = TRUE)
