library(lrstat)
library(jsonlite)

design <- read_json("/tmp/benchmark_github-issue-39/agent_A/output_A/gsd_results.json")

k <- 2
z_upper <- unlist(design$os_z_upper)
planned_events <- c(design$events_ia, design$events_fa)
total_n <- 9000
enroll_dur <- 48
gamma <- total_n / enroll_dur
hr <- design$hr_os
lambda_cv <- -log(1 - 0.025) / 12
eta <- -log(1 - 0.02) / 12

set.seed(12345)
sim_h1 <- lrsim(
  kMax = k,
  criticalValues = z_upper,
  futilityBounds = rep(-6, k - 1),
  allocation1 = 1, allocation2 = 1,
  accrualTime = 0,
  accrualIntensity = gamma,
  n = total_n,
  piecewiseSurvivalTime = 0,
  lambda1 = lambda_cv * hr,
  lambda2 = lambda_cv,
  gamma1 = eta, gamma2 = eta,
  plannedEvents = planned_events,
  maxNumberOfIterations = 5000
)

set.seed(67890)
sim_h0 <- lrsim(
  kMax = k,
  criticalValues = z_upper,
  futilityBounds = rep(-6, k - 1),
  allocation1 = 1, allocation2 = 1,
  accrualTime = 0,
  accrualIntensity = gamma,
  n = total_n,
  piecewiseSurvivalTime = 0,
  lambda1 = lambda_cv,
  lambda2 = lambda_cv,
  gamma1 = eta, gamma2 = eta,
  plannedEvents = planned_events,
  maxNumberOfIterations = 5000
)

power_sim <- sim_h1$overview$overallReject
alpha_sim <- sim_h0$overview$overallReject
events_sim <- sim_h1$overview$numberOfEvents
times_sim <- sim_h1$overview$analysisTime

log_lines <- c(
  "# GSD Verification Log",
  sprintf("**Design**: %s", design$disease),
  sprintf("**Date**: %s", Sys.Date()),
  sprintf("**Simulations**: 5000 reps"),
  "",
  "| Metric | Calculated | Simulated | Criterion | Pass? |",
  "|--------|-----------|-----------|-----------|-------|"
)

check_log <- function(name, calc, sim, tol) {
  diff <- abs(sim - calc)
  pass <- diff <= tol
  sprintf("| %s | %.2f | %.2f | ±%.2f | %s |", 
          name, calc, sim, tol, ifelse(pass, "PASS", "FAIL"))
}

log_lines <- c(log_lines, check_log("Power (%)", design$os_power * 100, power_sim * 100, 2.0))
log_lines <- c(log_lines, check_log("Type I Error (%)", design$alpha * 100, alpha_sim * 100, 0.5))
log_lines <- c(log_lines, check_log("IA Events", design$events_ia, events_sim[1], design$events_ia * 0.05))
log_lines <- c(log_lines, check_log("FA Events", design$events_fa, events_sim[2], design$events_fa * 0.05))
log_lines <- c(log_lines, check_log("IA Timing (mo)", design$ia_time, times_sim[1], 1.5))
log_lines <- c(log_lines, check_log("FA Timing (mo)", design$fa_time, times_sim[2], 1.5))

writeLines(log_lines, "/tmp/benchmark_github-issue-39/agent_A/output_A/gsd_verification_log.md")
