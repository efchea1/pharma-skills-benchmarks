# GSD Verification Log
**Design**: Cardiovascular Outcomes Trial (Phase 3)
**Date**: 2026-04-21
**Simulations**: 5000 reps

| Metric | Calculated | Simulated | Criterion | Pass? |
|--------|-----------|-----------|-----------|-------|
| Power (%) | 90.00 | 90.48 | ±2.00 | PASS |
| Type I Error (%) | 2.50 | 2.24 | ±0.50 | PASS |
| IA Events | 426.00 | 426.00 | ±21.30 | PASS |
| FA Events | 851.00 | 851.00 | ±42.55 | PASS |
| IA Timing (mo) | 50.41 | 50.45 | ±1.50 | PASS |
| FA Timing (mo) | 79.19 | 79.24 | ±1.50 | PASS |
